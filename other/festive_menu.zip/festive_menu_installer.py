import os
from os.path import expanduser
from colorama import Fore, Style, init

# Make Colorama automatically reset terminal color at the end of print statements
init(autoreset=True)

# Get the home directory of whoever is running this code
home = expanduser("~")
print(home)
gmodInstallDir = f"{home}/.steam/steam/steamapps/common/GarrysMod/garrysmod/"

menuOptions = [
    "Install custom GMod Main Menu",
    "Uninstall Menu",
    "Download files from game install",
    "Cancel",
]

while True:
    os.system("clear")

    print("GMod Custom Main Menu Install Tool")
    print(f"Made by {Fore.RED}Festive {Fore.GREEN}Colors")
    for i in range(len(menuOptions)):
        print(f"{i + 1}. {menuOptions[i]}")

    # Wait for user input
    userOption = int(input())

    if userOption == 1:
        print("Upload files to game install")
        os.system(f"cp -r html {gmodInstallDir}")

        os.system("clear")
        print("Custom menu successfully uploaded to game install")
        input()

    if userOption == 2:
        print("Uninstall GMod custom menu files")
        os.system(f"rm -r {gmodInstallDir}/html/")

        os.system("clear")
        print(
            "Custom menu uninstalled. You will have to validate the game files to get the default menu back."
        )
        input()

    if userOption == 3:
        os.system("clear")
        print("Download files from game install")
        print(
            f"{Fore.YELLOW} Warning: You can accidentally overwrite the custom files with this. Are you sure you want to copy the game directory files over? (y/n)"
        )
        yn = (
            input().lower()
        )  # Lowercase so it doesn't matter whether they use an uppercase or lowercase y

        if yn == "y" or yn == "1":
            os.system(f"cp -r {gmodInstallDir}/html/ .")

            print("Completed")
            input()

    if userOption == 4:
        exit(0)
